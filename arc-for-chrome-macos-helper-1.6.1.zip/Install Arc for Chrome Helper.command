#!/bin/bash
set -euo pipefail

script_root="$(cd "$(dirname "$0")" && pwd)"
bash "$script_root/install-macos-helper.sh"
echo
read -r -p "Installation finished. Press Return to close this window."
