#!/bin/bash
set -euo pipefail

host_name="com.arc_style_sidebar.window"
launch_agent="$HOME/Library/LaunchAgents/$host_name.plist"
launch_domain="gui/$(id -u)"

launchctl bootout "$launch_domain" "$launch_agent" >/dev/null 2>&1 || true
rm -f "$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts/$host_name.json"
rm -f "$launch_agent"
rm -f "/private/tmp/$host_name.command" "/private/tmp/$host_name.log" "/private/tmp/$host_name.err"
rm -rf "$HOME/Library/Application Support/Arc for Chrome" "$HOME/Library/Application Support/Arc-style Sidebar"

echo "Removed the Arc for Chrome macOS helper."
