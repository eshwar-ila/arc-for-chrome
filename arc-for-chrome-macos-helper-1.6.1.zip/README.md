# Arc for Chrome macOS helper

This optional local helper gives the sidebar the same compact left-edge window offset used by the reference profile and automatically matches Chrome's saved theme colour. Without it, the extension falls back to Chrome's window API and its selected fallback theme; tabs, spaces, history, archive, imports, exports, and shortcuts still work.

## Install

1. In the sidebar setup, select **Copy extension ID**.
2. Double-click **Install Arc for Chrome Helper.command** and paste the ID when asked.
3. If macOS opens Accessibility settings, add `/usr/bin/osascript` and enable it. This permission is used only to move the Chrome window.
4. Return to the sidebar setup and select **Recheck helper**.

Advanced users can instead run `bash install-macos-helper.sh EXTENSION_ID` in Terminal.

The helper accepts only local window bounds from the installed extension ID. For automatic theme matching, it reads only Chrome's locally saved theme seed and light/dark choice for the profile containing that extension ID. It does not read tabs, URLs, history, page contents, account data, or network data.

## Remove

Run `bash uninstall-macos-helper.sh`, then reload the extension. The extension continues to work using Chrome's built-in window API.
