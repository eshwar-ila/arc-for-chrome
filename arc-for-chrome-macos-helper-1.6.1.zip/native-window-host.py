#!/usr/bin/env python3
import json
import math
import os
import re
import subprocess
import struct
import sys
import time


def read_message():
    raw_length = sys.stdin.buffer.read(4)
    if not raw_length:
        return None
    length = struct.unpack("<I", raw_length)[0]
    if length > 1024 * 1024:
        raise ValueError("Native message exceeds Chrome's 1 MB limit.")
    return json.loads(sys.stdin.buffer.read(length).decode("utf-8"))


def write_message(message):
    payload = json.dumps(message).encode("utf-8")
    sys.stdout.buffer.write(struct.pack("<I", len(payload)))
    sys.stdout.buffer.write(payload)
    sys.stdout.buffer.flush()


def validated_bounds(value):
    if not isinstance(value, dict):
        raise ValueError("Window bounds must be an object.")
    bounds = {}
    for key in ("left", "top", "width", "height"):
        number = value.get(key)
        if isinstance(number, bool) or not isinstance(number, (int, float)) or not math.isfinite(number):
            raise ValueError("Window bounds must contain finite numbers.")
        bounds[key] = round(number)
    if not (-100000 <= bounds["left"] <= 100000 and -100000 <= bounds["top"] <= 100000):
        raise ValueError("Window position is outside the supported range.")
    if not (100 <= bounds["width"] <= 50000 and 100 <= bounds["height"] <= 50000):
        raise ValueError("Window size is outside the supported range.")
    return bounds


def request_animation(message):
    start = validated_bounds(message["from"])
    target = validated_bounds(message["to"])
    step_count = min(8, max(1, int(message.get("steps", 4))))
    step_delay = min(80, max(0, int(message.get("delayMs", 24)))) / 1000
    for step_number in range(1, step_count + 1):
        progress = step_number / step_count
        left = round(start["left"] + ((target["left"] - start["left"]) * progress))
        top = round(start["top"] + ((target["top"] - start["top"]) * progress))
        width = round(start["width"] + ((target["width"] - start["width"]) * progress))
        height = round(start["height"] + ((target["height"] - start["height"]) * progress))
        right = left + width
        bottom = top + height
        script = (
            'tell application "System Events" to tell process "Google Chrome" '
            f'to set {{position, size}} of front window to {{{{{left}, {top}}}, {{{width}, {height}}}}}'
        )
        subprocess.run(["/usr/bin/osascript", "-e", script], check=True, capture_output=True, text=True, timeout=5)
        if step_number < step_count:
            time.sleep(step_delay)


def accessibility_status():
    script = 'tell application "System Events" to tell process "Google Chrome" to count windows'
    result = subprocess.run(["/usr/bin/osascript", "-e", script], capture_output=True, text=True, timeout=5)
    return {
        "ok": True,
        "ready": result.returncode == 0,
        "error": "" if result.returncode == 0 else result.stderr.strip(),
    }


def chrome_theme(extension_id):
    if not isinstance(extension_id, str) or not re.fullmatch(r"[a-p]{32}", extension_id):
        raise ValueError("A valid Chrome extension ID is required.")
    chrome_root = os.path.expanduser("~/Library/Application Support/Google/Chrome")
    profile_directories = []
    try:
        with open(os.path.join(chrome_root, "Local State"), encoding="utf-8") as local_state_file:
            last_used = json.load(local_state_file).get("profile", {}).get("last_used")
        if isinstance(last_used, str):
            profile_directories.append(last_used)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        pass
    profile_directories.extend(["Default", *(name for name in os.listdir(chrome_root) if name.startswith("Profile "))])
    profile_directories = list(dict.fromkeys(profile_directories))
    for profile_directory in profile_directories:
        profile_root = os.path.join(chrome_root, profile_directory)
        try:
            with open(os.path.join(profile_root, "Secure Preferences"), encoding="utf-8") as preferences_file:
                secure_preferences = json.load(preferences_file)
            extension = secure_preferences.get("extensions", {}).get("settings", {}).get(extension_id)
            if extension is None:
                continue
            with open(os.path.join(profile_root, "Preferences"), encoding="utf-8") as preferences_file:
                preferences = json.load(preferences_file)
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            continue
        theme = preferences.get("browser", {}).get("theme", {})
        user_color = theme.get("user_color2", theme.get("user_color"))
        if not isinstance(user_color, int):
            return {"ok": True, "available": False}
        color_scheme = theme.get("color_scheme2", theme.get("color_scheme", 0))
        if color_scheme == 2:
            tone = "dark"
        elif color_scheme == 1:
            tone = "light"
        else:
            appearance = subprocess.run(
                ["/usr/bin/defaults", "read", "-g", "AppleInterfaceStyle"],
                capture_output=True,
                text=True,
                timeout=3,
            )
            tone = "dark" if appearance.returncode == 0 and appearance.stdout.strip() == "Dark" else "light"
        return {"ok": True, "available": True, "seed": f"#{user_color & 0xFFFFFF:06x}", "tone": tone}
    return {"ok": True, "available": False}


def main():
    while True:
        message = read_message()
        if message is None:
            return
        try:
            if message.get("action") == "status":
                write_message(accessibility_status())
            elif message.get("action") == "theme":
                write_message(chrome_theme(message.get("extensionId")))
            elif message.get("action") == "animateFrontWindow":
                request_animation(message)
                write_message({"ok": True})
            else:
                raise ValueError("Unsupported native window action.")
        except Exception as error:
            write_message({"ok": False, "error": str(error)})


if __name__ == "__main__":
    main()
