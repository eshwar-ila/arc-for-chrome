ARC FOR CHROME MIGRATION HELPER FOR macOS

1. Open Arc once and wait for its sidebar to finish loading. Arc may stay open.
2. Open “Prepare Arc Migration.command” once. If macOS says it cannot verify
   the file or offers to move it to Trash, dismiss the warning. Open System
   Settings > Privacy & Security, scroll to Security, choose Open Anyway,
   authenticate, then choose Open.
3. Wait for “Created” and the number of Arc history visits included.
4. In Arc for Chrome setup, choose “Move from Arc” and select the new
   “Arc for Chrome Migration … .arcsidebar” file from Downloads.

The one migration file contains Arc's exact Top Apps, Spaces, pinned and
unpinned tabs, nested folders, titles, order, Archive, and locally available
browsing history. It never contains passwords, cookies, extensions, or account
credentials. Everything stays on this Mac unless you move the file yourself.

The helper reads Arc's local files and writes only the migration file in
Downloads. It does not change Arc, connect to a server, or install anything.
The SHA-256 checksum published on the support page can verify the download.
