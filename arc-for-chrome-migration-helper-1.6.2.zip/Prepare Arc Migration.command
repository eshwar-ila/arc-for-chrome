#!/bin/bash
set -euo pipefail

clear
printf '%s\n' "Arc for Chrome — safe local Arc migration"
printf '%s\n' "This reads Arc's local sidebar, archive, history, and cached icons."
printf '%s\n' "It creates one migration file in Downloads, changes nothing in Arc,"
printf '%s\n\n' "and never uploads data or includes passwords, cookies, or accounts."

finish() {
  printf '\nPress Return to close…'
  read -r
}

TEMP_DIR=""
cleanup() {
  if [[ -n "$TEMP_DIR" && -d "$TEMP_DIR" ]]; then /bin/rm -rf "$TEMP_DIR"; fi
  finish
}
trap cleanup EXIT

ARC_DIR="$HOME/Library/Application Support/Arc"
SIDEBAR_SOURCE="$ARC_DIR/StorableSidebar.json"
ARCHIVE_SOURCE="$ARC_DIR/StorableArchiveItems.json"
HISTORY_ROOT="$ARC_DIR/User Data"
FAVICONS_SOURCE="$HISTORY_ROOT/Default/Favicons"

if [[ ! -s "$SIDEBAR_SOURCE" || ! -s "$ARCHIVE_SOURCE" ]]; then
  printf '%s\n' "Arc's local Spaces or Archive data was not found. Open Arc once, wait for the sidebar to load, then run this again." >&2
  exit 1
fi

TEMP_DIR=$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/arc-for-chrome-migration.XXXXXX")
SIDEBAR_COPY="$TEMP_DIR/StorableSidebar.json"
ARCHIVE_COPY="$TEMP_DIR/StorableArchiveItems.json"
HISTORY_CSV="$TEMP_DIR/arc-history.csv"
HISTORY_GZIP="$TEMP_DIR/arc-history.csv.gz"
URLS_FILE="$TEMP_DIR/arc-urls.txt"
FAVICONS_COPY="$TEMP_DIR/Favicons"
FAVICONS_TSV="$TEMP_DIR/arc-favicons.tsv"
FAVICONS_GZIP="$TEMP_DIR/arc-favicons.tsv.gz"

/bin/cp "$SIDEBAR_SOURCE" "$SIDEBAR_COPY"
/bin/cp "$ARCHIVE_SOURCE" "$ARCHIVE_COPY"
printf '"id","visited_at","title","url"\n' > "$HISTORY_CSV"

history_databases=0
while IFS= read -r -d '' database; do
  history_databases=$((history_databases + 1))
  profile=$(/usr/bin/basename "$(/usr/bin/dirname "$database")")
  profile_dir="$TEMP_DIR/history-$history_databases"
  /bin/mkdir "$profile_dir"
  database_copy="$profile_dir/History"
  /bin/cp "$database" "$database_copy"
  if [[ -f "$database-journal" ]]; then /bin/cp "$database-journal" "$profile_dir/History-journal"; fi
  if [[ -f "$database-wal" ]]; then /bin/cp "$database-wal" "$profile_dir/History-wal"; fi
  if [[ -f "$database-shm" ]]; then /bin/cp "$database-shm" "$profile_dir/History-shm"; fi
  escaped_profile=${profile//\'/\'\'}
  if ! /usr/bin/sqlite3 -readonly -csv "$database_copy" \
    "SELECT '$escaped_profile:' || visits.id, datetime((visits.visit_time / 1000000) - 11644473600, 'unixepoch', 'localtime'), COALESCE(NULLIF(urls.title, ''), urls.url), urls.url FROM visits JOIN urls ON visits.url = urls.id ORDER BY visits.visit_time;" \
    >> "$HISTORY_CSV"; then
    printf 'Could not create a safe history snapshot for Arc profile: %s\n' "$profile" >&2
    exit 1
  fi
done < <(/usr/bin/find "$HISTORY_ROOT" -mindepth 2 -maxdepth 2 -type f -name History -print0 2>/dev/null)

history_rows=$(( $(/usr/bin/wc -l < "$HISTORY_CSV") - 1 ))
history_size=0
if (( history_rows > 0 )); then
  /usr/bin/gzip -c "$HISTORY_CSV" > "$HISTORY_GZIP"
  history_size=$(/usr/bin/wc -c < "$HISTORY_GZIP" | /usr/bin/tr -d ' ')
elif (( history_databases > 0 )); then
  printf '%s\n' "Arc history databases were found, but no visits could be read. No migration file was created." >&2
  exit 1
fi

favicon_rows=0
favicon_size=0
if [[ -s "$FAVICONS_SOURCE" ]]; then
  /bin/cp "$FAVICONS_SOURCE" "$FAVICONS_COPY"
  if [[ -f "$FAVICONS_SOURCE-journal" ]]; then /bin/cp "$FAVICONS_SOURCE-journal" "$TEMP_DIR/Favicons-journal"; fi
  /usr/bin/osascript -l JavaScript "$(/usr/bin/dirname "$0")/Collect Arc URLs.js" "$SIDEBAR_COPY" "$ARCHIVE_COPY" > "$URLS_FILE"
  /usr/bin/sqlite3 -readonly "$FAVICONS_COPY" <<SQL
CREATE TEMP TABLE wanted(url TEXT PRIMARY KEY);
.mode tabs
.import '$URLS_FILE' wanted
.output '$FAVICONS_TSV'
WITH ranked AS (
  SELECT wanted.url,
         hex(favicon_bitmaps.image_data) AS image_hex,
         row_number() OVER (
           PARTITION BY wanted.url
           ORDER BY CASE WHEN favicon_bitmaps.width BETWEEN 16 AND 128 THEN 0 ELSE 1 END,
                    abs(favicon_bitmaps.width - 64),
                    favicon_bitmaps.last_updated DESC
         ) AS position
  FROM wanted
  JOIN icon_mapping ON icon_mapping.page_url = wanted.url
  JOIN favicon_bitmaps ON favicon_bitmaps.icon_id = icon_mapping.icon_id
  WHERE length(favicon_bitmaps.image_data) > 0
)
SELECT url, image_hex FROM ranked WHERE position = 1;
SQL
  if [[ -s "$FAVICONS_TSV" ]]; then
    favicon_rows=$(/usr/bin/wc -l < "$FAVICONS_TSV" | /usr/bin/tr -d ' ')
    /usr/bin/gzip -c "$FAVICONS_TSV" > "$FAVICONS_GZIP"
    favicon_size=$(/usr/bin/wc -c < "$FAVICONS_GZIP" | /usr/bin/tr -d ' ')
  fi
fi

sidebar_size=$(/usr/bin/wc -c < "$SIDEBAR_COPY" | /usr/bin/tr -d ' ')
archive_size=$(/usr/bin/wc -c < "$ARCHIVE_COPY" | /usr/bin/tr -d ' ')
date_stamp=$(/bin/date '+%Y-%m-%d %H%M%S')
OUTPUT="$HOME/Downloads/Arc for Chrome Migration $date_stamp.arcsidebar"
{
  printf 'ARC_SIDEBAR_BUNDLE_V3\n'
  printf '{"format":"arc-sidebar-migration","version":3,"sidebarLength":%s,"archiveLength":%s,"historyLength":%s,"faviconLength":%s,"historyName":"arc-history.csv.gz","faviconName":"arc-favicons.tsv.gz"}\n' "$sidebar_size" "$archive_size" "$history_size" "$favicon_size"
  /bin/cat "$SIDEBAR_COPY"
  /bin/cat "$ARCHIVE_COPY"
  if (( history_size > 0 )); then /bin/cat "$HISTORY_GZIP"; fi
  if (( favicon_size > 0 )); then /bin/cat "$FAVICONS_GZIP"; fi
} > "$OUTPUT"

printf '\nCreated: %s\n' "$OUTPUT"
printf 'Arc history visits included: %s\n' "$history_rows"
printf 'Arc favicons included: %s\n' "$favicon_rows"
printf '%s\n' "Includes exact Spaces, Top Apps, pinned and unpinned tabs, folders, Archive, titles, order, history, and cached icons."
printf '%s\n' "Passwords, cookies, extensions, and account credentials are never included."
