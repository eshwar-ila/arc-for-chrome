#!/usr/local/bin/python3
import base64
import json
import math
import os
import re
import subprocess
import struct
import sys
import time


def read_message():
    raw_length = sys.stdin.buffer.read(4)
    if not raw_length:
        return None
    length = struct.unpack("<I", raw_length)[0]
    if length > 1024 * 1024:
        raise ValueError("Native message exceeds Chrome's 1 MB limit.")
    return json.loads(sys.stdin.buffer.read(length).decode("utf-8"))


def write_message(message):
    payload = json.dumps(message).encode("utf-8")
    sys.stdout.buffer.write(struct.pack("<I", len(payload)))
    sys.stdout.buffer.write(payload)
    sys.stdout.buffer.flush()


def validated_bounds(value):
    if not isinstance(value, dict):
        raise ValueError("Window bounds must be an object.")
    bounds = {}
    for key in ("left", "top", "width", "height"):
        number = value.get(key)
        if isinstance(number, bool) or not isinstance(number, (int, float)) or not math.isfinite(number):
            raise ValueError("Window bounds must contain finite numbers.")
        bounds[key] = round(number)
    if not (-100000 <= bounds["left"] <= 100000 and -100000 <= bounds["top"] <= 100000):
        raise ValueError("Window position is outside the supported range.")
    if not (100 <= bounds["width"] <= 50000 and 100 <= bounds["height"] <= 50000):
        raise ValueError("Window size is outside the supported range.")
    return bounds


def request_animation(message):
    start = validated_bounds(message["from"])
    target = validated_bounds(message["to"])
    step_count = min(8, max(1, int(message.get("steps", 4))))
    step_delay = min(80, max(0, int(message.get("delayMs", 24)))) / 1000
    for step_number in range(1, step_count + 1):
        progress = step_number / step_count
        left = round(start["left"] + ((target["left"] - start["left"]) * progress))
        top = round(start["top"] + ((target["top"] - start["top"]) * progress))
        width = round(start["width"] + ((target["width"] - start["width"]) * progress))
        height = round(start["height"] + ((target["height"] - start["height"]) * progress))
        right = left + width
        bottom = top + height
        script = (
            'tell application "System Events" to tell process "Google Chrome" '
            f'to set {{position, size}} of front window to {{{{{left}, {top}}}, {{{width}, {height}}}}}'
        )
        subprocess.run(["/usr/bin/osascript", "-e", script], check=True, capture_output=True, text=True, timeout=5)
        if step_number < step_count:
            time.sleep(step_delay)


def accessibility_status():
    script = 'tell application "System Events" to tell process "Google Chrome" to count windows'
    result = subprocess.run(["/usr/bin/osascript", "-e", script], capture_output=True, text=True, timeout=5)
    return {
        "ok": True,
        "ready": result.returncode == 0,
        "error": "" if result.returncode == 0 else result.stderr.strip(),
    }


def chrome_profile_path():
    # Chrome can supply these switches in its native-host metadata. Never execute them.
    for arg in sys.argv[2:]:
        if arg.startswith("--reconnect-command="):
            args = json.loads(base64.b64decode(arg.split("=", 1)[1]))
            options = dict(item[2:].split("=", 1) for item in args if item.startswith("--") and "=" in item)
            root, name = options.get("user-data-dir"), options.get("profile-directory")
            if root and name and os.path.isabs(root) and name == os.path.basename(name):
                return os.path.join(root, name)
    return ""

def chrome_theme(message):
    instance = message.get("instance", "")
    if not re.fullmatch(r"[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}", instance):
        raise ValueError("Invalid installation.")
    link = message.get("action") == "linkTheme"
    root = os.path.dirname(os.path.abspath(__file__))
    bookmark = os.path.join(root, instance + ".bookmark")
    profile = chrome_profile_path()
    if not profile and link:
        profile = message.get("profilePath", "")
        if profile and (not os.path.isabs(profile) or not os.path.isfile(os.path.join(profile,"Preferences"))):
            return {"needsProfilePath": True}
    if link and not profile:
        return {"needsProfilePath": True}
    if not link and not os.path.isfile(bookmark):
        if not profile: return {"needsProfilePath": True}
        raise PermissionError("Permission denied. Allow automatic theme matching.")
    result = subprocess.run(["/usr/bin/osascript", "-l", "JavaScript", os.path.join(root,"theme-link.js"),
                             "link" if link else "read", profile, bookmark],
                            capture_output=True, text=True, timeout=180 if link else 8)
    if result.returncode:
        raise ValueError("Could not read the Chrome theme.")
    linked = json.loads(result.stdout)
    if not linked.get("ok"):
        raise PermissionError("Permission denied. " + linked.get("error", "Allow automatic theme matching."))
    user_color, color_scheme = linked.get("color"), linked.get("scheme")
    if not isinstance(user_color, int):
        return {"ok": True, "available": False}
    if color_scheme == 2:
        tone = "dark"
    elif color_scheme == 1:
        tone = "light"
    else:
        appearance = subprocess.run(
            ["/usr/bin/defaults", "read", "-g", "AppleInterfaceStyle"],
            capture_output=True,
            text=True,
            timeout=3,
        )
        tone = "dark" if appearance.returncode == 0 and appearance.stdout.strip() == "Dark" else "light"
    return {"ok": True, "available": True, "seed": f"#{user_color & 0xFFFFFF:06x}", "tone": tone}


def main():
    while True:
        message = read_message()
        if message is None:
            return
        try:
            if message.get("action") == "compactPanel":
                window_id, edge = message.get("windowId"), message.get("edge")
                if type(window_id) is not int or window_id <= 0 or type(edge) is not int:
                    raise ValueError("Invalid window.")
                offset = message.get("offset", 112)
                if type(offset) is not int or not 64 <= offset <= 1024:
                    raise ValueError("Invalid offset.")
                with subprocess.Popen([sys.executable, os.path.join(os.path.dirname(__file__), "layout-lease.py"),
                                       str(window_id), str(edge), str(offset)], stdin=subprocess.PIPE,
                                      stdout=subprocess.PIPE, start_new_session=True) as guard:
                    try:
                        write_message(json.loads(guard.stdout.readline()))
                        while True:
                            request = read_message()
                            if request is None:
                                break
                            width_offset = request.get("offset")
                            if request.get("action") != "resize" or type(width_offset) is not int or not 64 <= width_offset <= 1024:
                                raise ValueError("Invalid resize request.")
                            guard.stdin.write(f"{width_offset}\n".encode())
                            guard.stdin.flush()
                            write_message(json.loads(guard.stdout.readline()))
                    finally:
                        guard.stdin.close()
                return
            elif message.get("action") == "capabilities":
                write_message({"ok": True, "compactPanel": True})
            elif message.get("action") == "status":
                write_message(accessibility_status())
            elif message.get("action") in ("theme", "linkTheme"):
                write_message(chrome_theme(message))
            elif message.get("action") == "animateFrontWindow":
                request_animation(message)
                write_message({"ok": True})
            else:
                raise ValueError("Unsupported native window action.")
        except Exception as error:
            write_message({"ok": False, "error": str(error)})


if __name__ == "__main__":
    main()
