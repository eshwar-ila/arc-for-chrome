ObjC.import("AppKit");
ObjC.import("Foundation");
function run(args) {
    const profile = args[1];
    const bookmark = args[2];
    const original = profile ? $.NSURL.fileURLWithPathIsDirectory(profile,true) : null;
    const error = Ref();
    const linked = args[0] === "link";
    let url;
    if (linked) {
        $.NSApplication.sharedApplication.setActivationPolicy($.NSApplicationActivationPolicyAccessory);
        $.NSApp.activateIgnoringOtherApps(true);
        const panel = $.NSOpenPanel.openPanel;
        panel.title = "Allow Chrome theme matching";
        panel.message = "Allow read access to this Chrome profile folder. The helper reads Preferences to obtain the theme color and appearance.";
        panel.prompt = "Allow theme access";
        panel.canChooseDirectories = true;
        panel.canChooseFiles = false;
        panel.canCreateDirectories = false;
        panel.directoryURL = $.NSURL.fileURLWithPath(profile);

        if (panel.runModal !== $.NSModalResponseOK) return JSON.stringify({ok:false,error:"Selection cancelled."});
        url = panel.URL;
    } else {
        const token = $.NSData.dataWithContentsOfFile(bookmark);
        if (!token || token.isNil()) return JSON.stringify({ok:false,error:"Theme access has not been linked."});
        const stale = Ref();
        url = $.NSURL.URLByResolvingBookmarkDataOptionsRelativeToURLBookmarkDataIsStaleError(token, 1024 | 256, $(), stale, error);
    }
    if (!url || url.isNil() || (original && ObjC.unwrap(url.path) !== ObjC.unwrap(original.path)))
        return JSON.stringify({ok:false,error:"Approve the current Chrome profile folder."});
    const accessed = url.startAccessingSecurityScopedResource;
    try {
        const raw = $.NSString.stringWithContentsOfURLEncodingError(url.URLByAppendingPathComponent("Preferences"), $.NSUTF8StringEncoding, error);
        if (!raw || raw.isNil()) return JSON.stringify({ok:false,error:"macOS denied access to the linked theme."});
        const theme = JSON.parse(ObjC.unwrap(raw)).browser?.theme || {};
        if (linked) {
            const data = url.bookmarkDataWithOptionsIncludingResourceValuesForKeysRelativeToURLError(2048 | 4096, $(), $(), error);
            if (!data || data.isNil() || !data.writeToFileAtomically(bookmark,true))
                return JSON.stringify({ok:false,error:"macOS could not save persistent theme access."});
        }
        return JSON.stringify({ok:true,color:theme.user_color2 ?? theme.user_color,scheme:theme.color_scheme2 ?? theme.color_scheme});
    } finally { if (accessed) url.stopAccessingSecurityScopedResource; }
}
