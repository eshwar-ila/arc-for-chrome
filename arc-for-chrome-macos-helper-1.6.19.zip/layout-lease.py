"""Hold a reversible compact layout for a single Chrome side panel."""
import fcntl
import json
import os
import subprocess
import sys

window_id, edge, offset = map(int, sys.argv[1:])
target = f'window id {window_id}'

def apple(statement):
    return subprocess.check_output(['/usr/bin/osascript', '-e',
        f'tell application "Google Chrome" to {statement}'], text=True, stderr=subprocess.PIPE, timeout=4).strip()

def bounds():
    return tuple(map(int, apple(f'get bounds of {target}').split(', ')))

def move(rect):
    apple(f'set bounds of {target} to {{' + ', '.join(map(str, rect)) + '}')

def report(active, offset=0):
    print(json.dumps({'active': active, 'offset': offset}), flush=True)

def run():
    with open(os.path.join(os.path.dirname(__file__), f'.layout-{window_id}.lock'), 'a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        original = bounds()
        left, top, right, bottom = original
        if abs(left - edge) > 3 or right-left < 500:
            report(False)
            return
        cropped = left - offset
        try:
            move((cropped, top, right, bottom))
            confirmed = abs(bounds()[0] - cropped) <= 2
            report(confirmed, offset)
            if confirmed:
                for line in sys.stdin.buffer:
                    requested = int(line)
                    if not 64 <= requested <= 1024:
                        break
                    x, y, r, b = bounds()
                    if abs(x - cropped) > 2:
                        break
                    cropped = left - requested
                    move((cropped, y, r, b))
                    report(abs(bounds()[0] - cropped) <= 2, requested)
        finally:
            x, y, r, b = bounds()
            if abs(x - cropped) <= 2:
                move((left, y, r, b))

if __name__ == '__main__':
    try:
        run()
    except Exception as error:
        with open(os.path.join(os.path.dirname(__file__), '.layout-error'), 'w') as log:
            log.write(str(getattr(error, 'stderr', '') or error)[:500])
        report(False)
