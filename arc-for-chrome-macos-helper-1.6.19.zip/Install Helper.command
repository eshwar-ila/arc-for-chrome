#!/bin/bash
set -eu
cd "$(dirname "$0")"
python_path="$(command -v python3)"
"$python_path" - <<'PY'
import json, pathlib, shutil, sys, tempfile, os
home = pathlib.Path.home()
root = home / "Library/Application Support/Arc for Chrome/Store Helper"
root.mkdir(parents=True,exist_ok=True,mode=0o700)
hosts = home / "Library/Application Support/Google/Chrome/NativeMessagingHosts"
hosts.mkdir(parents=True,exist_ok=True,mode=0o700)
name = "com.arcforchrome.store_layout"
manifest = hosts / (name + ".json")
origins = json.loads(manifest.read_text())["allowed_origins"] if manifest.exists() else []
origin = "chrome-extension://mhmfcepflnlphogaaelglppgoljbkklm/"
if set(origins) - {origin}:
    sys.exit("This host also serves a different extension. Existing helper preserved.")
def install(path, data, mode):
    with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as f:
        f.write(data)
        os.chmod(f.name,mode)
    os.replace(f.name,path)
install(root/"layout-lease.py", pathlib.Path("layout-lease.py").read_bytes(),0o600)
install(root/"theme-link.js", pathlib.Path("theme-link.js").read_bytes(),0o600)
host = root/"native-window-host.py"
src = pathlib.Path("native-window-host.py").read_text().split("\n",1)[1]
install(host, ("#!"+sys.executable+"\n"+src).encode(),0o755)
install(manifest,json.dumps(dict(name=name,description="Arc for Chrome sidebar layout and theme",path=str(host),type="stdio",supports_native_initiated_connections=True,allowed_origins=[origin])).encode(),0o600)
print("Installed. Open sidebar settings and select Recheck helper.")
PY
