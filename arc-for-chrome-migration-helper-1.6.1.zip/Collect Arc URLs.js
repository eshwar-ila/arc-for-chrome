ObjC.import("Foundation");

function readJson(path) {
    const data = $.NSData.dataWithContentsOfFile($(path));
    if (!data) throw new Error(`Could not read ${path}`);
    const text = $.NSString.alloc.initWithDataEncoding(data, $.NSUTF8StringEncoding).js;
    return JSON.parse(text);
}

function run(arguments) {
    const sidebar = readJson(arguments[0]);
    const archive = readJson(arguments[1]);
    const urls = new Set();
    const addUrl = (value) => {
        const url = value?.data?.tab?.savedURL;
        if (!/^https?:\/\//i.test(url || "")) return;
        const clean = url.replace(/[\t\r\n]/g, "");
        urls.add(clean);
        try {
            urls.add(new URL(clean).origin + "/");
        } catch {}
    };
    for (const entry of sidebar?.sidebarSyncState?.items || []) {
        if (entry && typeof entry === "object") addUrl(entry.value);
    }
    for (const entry of archive?.items || []) {
        if (entry && typeof entry === "object") addUrl(entry.sidebarItem);
    }
    return [...urls].join("\n");
}
