#!/bin/bash
set -euo pipefail

extension_id="${1:-}"
if [[ -z "$extension_id" ]]; then
  echo "In the Arc for Chrome sidebar, open Setup and privacy, then select Copy extension ID."
  read -r -p "Extension ID: " extension_id
fi
if [[ ! "$extension_id" =~ ^[a-p]{32}$ ]]; then
  echo "Usage: $0 <32-character Chrome extension ID>" >&2
  echo "Copy the ID from Arc for Chrome → Setup and privacy → Copy extension ID." >&2
  exit 2
fi

helper_root="$HOME/Library/Application Support/Arc for Chrome"
native_hosts="$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"
launch_agents="$HOME/Library/LaunchAgents"
host_name="com.arc_style_sidebar.window"
host_manifest="$native_hosts/$host_name.json"
launch_agent="$launch_agents/$host_name.plist"
script_root="$(cd "$(dirname "$0")" && pwd)"

mkdir -p "$helper_root" "$native_hosts" "$launch_agents"
install -m 755 "$script_root/native-window-host.py" "$helper_root/native-window-host.py"

plutil -create xml1 "$host_manifest"
plutil -insert name -string "$host_name" "$host_manifest"
plutil -insert description -string "Resize the Chrome window for Arc for Chrome" "$host_manifest"
plutil -insert path -string "$helper_root/native-window-host.py" "$host_manifest"
plutil -insert type -string "stdio" "$host_manifest"
plutil -insert allowed_origins -json "[\"chrome-extension://$extension_id/\"]" "$host_manifest"
plutil -convert json "$host_manifest"

launch_domain="gui/$(id -u)"
launchctl bootout "$launch_domain" "$launch_agent" >/dev/null 2>&1 || true
rm -f "$launch_agent" "/private/tmp/$host_name.command" "/private/tmp/$host_name.log" "/private/tmp/$host_name.err"

echo "Installed the Arc for Chrome macOS helper for extension $extension_id."
echo "Return to Arc for Chrome setup and select Recheck helper."

if ! /usr/bin/osascript -e 'tell application "System Events" to tell process "Google Chrome" to count windows' >/dev/null 2>&1; then
  echo "Accessibility permission is still required for osascript."
  echo "System Settings is opening now. Under Privacy & Security → Accessibility:"
  echo "  1. Select + and authenticate if asked."
  echo "  2. Press Command-Shift-G, enter /usr/bin/osascript, then select Open."
  echo "  3. Turn osascript on, return to Arc for Chrome, and select Recheck helper."
  open 'x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility'
fi
