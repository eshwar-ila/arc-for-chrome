#!/bin/bash
set -euo pipefail

script_root="$(cd "$(dirname "$0")" && pwd)"
clear
echo "Arc for Chrome — optional compact-layout helper"
echo ""
echo "This installs a local helper that can move the front Chrome window and read"
echo "Chrome's saved theme choice. It cannot read tabs, history, page contents,"
echo "passwords, accounts, or network traffic. Nothing is uploaded."
echo ""
bash "$script_root/install-macos-helper.sh"
echo
read -r -p "Installation finished. Press Return to close this window."
